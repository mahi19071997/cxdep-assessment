import React from 'react'

export function TodoList({status,title,handleDelete,handleToggle,id}) {
  return (
    <div>
      <h1>{title}</h1>
      <h1>{status ? "Done" : "Not Done"}</h1>
      <button onClick={()=>{handleToggle(id)}}>Toggle</button>
      <button onClick={()=>{handleDelete(id)}}>Delete</button>
    </div>
  )
}
